//
//  ShareButtonSwiftUIApp.swift
//  ShareButtonSwiftUI
//
//  Created by Shreyas Vilaschandra Bhike on 08/05/21.
//

import SwiftUI

@main
struct ShareButtonSwiftUIApp: App {
    var body: some Scene {
        WindowGroup {
            ContentView()
        }
    }
}
